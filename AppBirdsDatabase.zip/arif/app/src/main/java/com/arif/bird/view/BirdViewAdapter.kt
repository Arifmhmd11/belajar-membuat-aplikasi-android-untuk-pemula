package com.arif.bird.view

import android.content.Intent
import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.arif.bird.R
import com.arif.bird.data.Bird


class BirdViewAdapter(private val listBirds: ArrayList<Bird>) : RecyclerView.Adapter<BirdViewAdapter.CardViewViewHolder>() {
    private lateinit var onItemClickCallback: OnItemClickCallback
    private lateinit var onButtonClickCallback: OnItemClickCallback
    private lateinit var onFavoriteClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    fun setOnButtonClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onButtonClickCallback = onItemClickCallback
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.view_card_data, parent, false)
        return CardViewViewHolder(view)
    }

    override fun onBindViewHolder(holder: CardViewViewHolder, position: Int){
        val bird = listBirds[position]
        Glide.with(holder.itemView.context)
            .load(bird.photo)
            .apply(RequestOptions().override(350, 550))
            .into(holder.imgPhoto)
        holder.tvName.text = bird.name
        holder.tvLatinName.text = bird.latinName

        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(listBirds[holder.adapterPosition]) }
        //using button share to whatsApp!
        holder.btnShare.setOnClickListener {
            onButtonClickCallback.onItemClicked(listBirds[holder.adapterPosition])
        }

    }

    override fun getItemCount(): Int {
        return listBirds.size
    }

    inner class CardViewViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)
        var tvName: TextView = itemView.findViewById(R.id.tv_item_name)
        var tvLatinName: TextView = itemView.findViewById(R.id.tv_item_latinName)
        var btnShare: ImageButton = itemView.findViewById(R.id.btn_set_share)
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: Bird)
    }
}