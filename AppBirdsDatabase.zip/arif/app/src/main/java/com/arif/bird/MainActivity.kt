package com.arif.bird

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.arif.bird.`object`.DataBird
import com.arif.bird.data.Bird
import com.arif.bird.view.Detail
import com.arif.bird.view.BirdViewAdapter
import com.arif.bird.view.Profil

class MainActivity : AppCompatActivity() {
    private lateinit var rvViews: RecyclerView
    private var listBirds: ArrayList<Bird> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvViews = findViewById(R.id.rv_heroes)
        rvViews.setHasFixedSize(true)

        listBirds.addAll(DataBird.listData)
        showRecyclerCardView()
    }

    private fun showRecyclerCardView() {
        rvViews.layoutManager = LinearLayoutManager(this)
        val cardViewBird = BirdViewAdapter(listBirds)
        rvViews.adapter = cardViewBird

        cardViewBird.setOnItemClickCallback(object : BirdViewAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Bird) {
                showBirdSelected(data)
            }
        })

        cardViewBird.setOnButtonClickCallback(object : BirdViewAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Bird) {
                sendMessage(data)
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        setMode(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun setMode(selectedMode: Int) {
        when (selectedMode) {
            R.id.action_list -> {
                myProfil()
            }
        }
    }

    private fun myProfil(){
        val intent = Intent(this, Profil::class.java)
        startActivity(intent)
    }

    private fun showBirdSelected(bird: Bird) {
        Toast.makeText(this, "Kamu memilih " + bird.name, Toast.LENGTH_SHORT).show()
        val moveData = Intent(this, Detail::class.java)
        moveData.putExtra(Detail.EXTRA_NAME, bird.name)
        moveData.putExtra(Detail.EXTRA_LATINNAME, bird.latinName)
        moveData.putExtra(Detail.EXTRA_IMAGE, bird.photo)
        moveData.putExtra(Detail.EXTRA_DETAIL, bird.detail)
        startActivity(moveData)
    }

    private fun sendMessage(bird: Bird){
        val judul = bird.name
        val latinName = bird.latinName
        val detail = bird.detail

        val message = "Nama bird : *$judul*,\nNama Latin : _" + latinName +"_,\n \n$detail"

        val intent = Intent(Intent.ACTION_SEND)
        intent.putExtra(Intent.EXTRA_TEXT, message)
        intent.type = "text/plain"

        startActivity(Intent.createChooser(intent, "Share using .."))
    }
}
