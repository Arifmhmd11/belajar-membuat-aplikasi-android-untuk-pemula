package com.arif.bird.data

data class Bird(
    var name:String = "",
    var latinName:String = "",
    var detail:String = "",
    var photo:Int = 0
)
