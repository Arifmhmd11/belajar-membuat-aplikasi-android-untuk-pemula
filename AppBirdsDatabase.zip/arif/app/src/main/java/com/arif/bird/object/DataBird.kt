package com.arif.bird.`object`

import com.arif.bird.R
import com.arif.bird.data.Bird

object DataBird {
    private val birdNames = arrayOf(
        "Burung Murai Batu",
        "Burung Kacer",
        "Burung Kenari",
        "Burung Love Bird",
        "Burung Cucok Ijo (Hijau)",
        "Burung Cendet (Pentet)",
        "Burung Kacamata (Peleci)",
        "Burung Prenjak (Ciblek)",
        "Burung Glatik Batu",
        "Burung Anis Merah (Punglor)")
    private val latinBirdName = arrayOf(
        "Rank 1",
        "Rank 2",
        "Rank 3",
        "Rank 4",
        "Rank 5",
        "Rank 6",
        "Rank 7",
        "Rank 8",
        "Rank 9",
        "Rank 10")
    private val birdImages = arrayOf(
         R.drawable.burung_murai,
         R.drawable.burung_kacer,
         R.drawable.burung_kenari,
         R.drawable.burung_love_bird,
         R.drawable.burung,
         R.drawable.burung_cendet,
         R.drawable.burung_kaca_mata,
         R.drawable.burung_prenjak,
         R.drawable.burung_gelatik_batu,
         R.drawable.burung_anis_merah)
    private val birdDetails = arrayOf(
        "Disukai karena elegan dari penampilan dan suaranya serta gaya sombong penampilannya serta hebatnya lagi bisa menirukan suara burung-burung yang lainnya tanpa meninggalkan suara khasnya." +
            "Harga burung ini mulai dari Rp 600 ribu - Rp 3,5 juta dan jika sudah gacor," +
            "sudah ikut kontes dan bahkan mendapat kategori juara harga bisa sampai Rp 40 juta bahkan bisa lebih."
        ,"Memiliki warna hitam yang dominan pada bulu." +
            "Hampir Seluruh tubuh berwarna hitam," +
            "kecuali pada sayap dan dada bawahnya terdapat warna putih. Harga kacer : berkisar antara Rp 250 ribu - Rp 1,5 juta."
        ,"Menjadi pilihan kicau mania karena coraknya yang bagus dengan kicauan merdu dan mudah sekali untuk dibudidayakan."
        ,"Burung yang melambangkan kesetian ini juga sangat di gemari. Harga berkisar Rp 600 ribu - Rp 1,2 juta."
        ,"Sesuai dengan namanya Burung Cucak Ijo memiliki warna dominan hijau dengan sedikit warna hitam pada kepala dan paruh." +
                "Banyak terdapat di Pulau Jawa, Sumatera, Bali, dan Kalimantan." +
                "Burung ini hidup berkelompok di Hutan, dan terbang dari satu pohon ke pohon lainnya yang tinggi."
        ,"Burung ini diminati karena kepandaianya berkicau bisa menirukan kicauan burung lainya contohnya bisa menirukan suara jangkrik," +
                "menirukan suara burung prenjak dan bisa menirukan burung jenis kutilang." +
                "Harga burung pentet relatif cukup murah jika dibandingkan dengan kenari, kacer dan murai batu yaitu sekitar Rp 200 ribu - Rp 600 ribu (tergantung kondisi dan fisik burung)."
        ,"Sekalipun kecil, karena dengan keunikan suara ocehannya burung ini sangat  sering diikutsertakan dalam lomba burng kicauan."
        ,"Dikenal juga sebagai perenjak jawa. Burung ini termasuk burung endemik Jawa, Sumatera, dan Bali."+
                "Harga Berkisar antara Rp 80 ribu - Rp 700 ribuan (tergantung kualitas)."
        ,"Dengan suaranya yang khas yang melengking,"+
                "sehingga burung ini sering dijadikan sebagai brung master untuk isian burung-burung yang lain untuk mengkombinasikan suara burung yang lain biar lebih bervariasi ocehannya."+
                "Harga berkisar, Rp 100 rb - Rp 700 rb (jika sudah gacor)."
        ,"Burung yang satu ini mempunyai gaya yang sangat khas. Yaitu, gaya khas telernya saat bersuara."
    )


    val listData: ArrayList<Bird>
        get() {
            val list = arrayListOf<Bird>()
            for (position in birdNames.indices) {
                val hero = Bird()
                hero.name = birdNames[position]
                hero.latinName = latinBirdName[position]
                hero.detail = birdDetails[position]
                hero.photo = birdImages[position]
                list.add(hero)
            }
            return list
        }
}